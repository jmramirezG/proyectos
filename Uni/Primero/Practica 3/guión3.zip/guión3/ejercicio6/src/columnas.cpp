#include <iostream>
#include "columnas.h"

using namespace std;

struct Columnas;