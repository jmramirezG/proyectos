#ifndef utilidades_h
#define utilidades_h

void orden(double *array, int tamanio);

void mostrar(double *array, int tamanio);

int calcularTamRes(double *array1, int tamanio1, double *array2, int tamanio2);

int mezclarUnico(double *array1, int tamanio1, double *array2, int tamanio2, double *mezcla, int const tamanioMezcla);

#endif