#ifndef Utilidades_h
#define Utilidades_h

void mostrarArray(int const array[], int const util);

void mostrarArrayPtr(int **array,int const util);

void ordenarPunteros(int *array, int const util, int **resultado);

#endif