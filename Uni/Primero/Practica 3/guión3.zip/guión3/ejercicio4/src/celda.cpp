#include <iostream>
#include "celda.h"

using namespace std;

class Celda;