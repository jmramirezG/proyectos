#ifndef utilidades_h
#define utilidades_h

#include <iostream>
#include "punto.h"
#include "polilinea.h"

using namespace std;

ostream& operator<<(ostream &o, const Polilinea &mostrar);

#endif