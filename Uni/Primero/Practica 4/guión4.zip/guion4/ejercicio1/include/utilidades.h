#ifndef utilidades_h
#define utilidades_h

#include <iostream>
#include <string>
#include "bigint.h"

using namespace std;

ostream& operator << (ostream &o, const BigInt &mostrar);

#endif