#ifndef utilidades_h
#define utilidades_h

#include <iostream>
#include "matrizdispersa.h"
#include "valor.h"

using namespace std;

ostream& operator<<(ostream &o, const MatrizDispersa &mostrar);

#endif