#ifndef utilidades_h
#define utilidades_h

#include <iostream>
#include "precuencias.h"
#include "pareja.h"

using namespace std;

ostream & operator<<(ostream &o, const Precuencias &mostrar);

#endif