#ifndef utilidades_h
#define utilidades_h

#include "Valor.h"

void combinarSuma(Valor serie1[], Valor serie2[], int tamanioSerie1, int tamanioSerie2, Valor suma[], int &total);

#endif