#ifndef utilidades_h
#define utilidades_h

void Creciente(int cadena1[], int cadena_crece[], int &utilizados);

#endif