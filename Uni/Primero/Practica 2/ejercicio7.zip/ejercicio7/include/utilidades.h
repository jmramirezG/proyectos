#ifndef utilidades_h
#define utilidades_h

void descomponer(int numero, int factores[], int &numeroFactores);

#endif