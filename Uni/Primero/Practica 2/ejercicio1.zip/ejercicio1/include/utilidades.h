#ifndef utilidades_h
#define utilidades_h

int mezclar(double Array1[], double Array2[], int tamanioA1, int tamanioA2, double ArrayResultado[]);

#endif