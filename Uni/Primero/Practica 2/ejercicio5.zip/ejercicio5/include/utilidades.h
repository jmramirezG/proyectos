#ifndef utilidades_h
#define utilidades_h

bool InsertarCadena(char cadena[], char insertar[], int tamanioCad, int tamanioIns, int posicion, char cadenaCompleta[]);

#endif