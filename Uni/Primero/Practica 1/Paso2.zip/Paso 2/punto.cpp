#include<iostream>
#include "punto.h"

using namespace std;

/**
 * Muestra el contenido del objeto por pantalla. A implementar
 */
void Punto::mostrar() const {
    // Formato de escritura del punto: (x,y)
    cout << "(" << x << ", " << y << ")\n";
}

/**
 * Metodo para preguntar los valores de los datos miembro al
 * usuario. Por implementar
 */
void Punto::leerDatos(){
    // Se leen los datos del usaurio
    cout << "Valor de x: ";
    cin >> x;
    cout << "\nValor de y: ";
    cin >> y;
}
